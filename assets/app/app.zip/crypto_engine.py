"""
🔒 التشفير الهجين والتوقيع الرقمي
Hybrid Encryption (AES-256-GCM + RSA-2048) & Digital Signatures
"""
import os
import hashlib
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import hashes, serialization
from container_format import SHEPContainer


class HybridEncryptor:
    """
    التشفير الهجين: AES-256-GCM للبيانات + RSA-OAEP للمفتاح.
    """

    @staticmethod
    def encrypt(data: bytes, recipient_public_key) -> bytes:
        """
        تشفير البيانات باستخدام المفتاح العام للمستلم.
        
        Args:
            data: البيانات المراد تشفيرها
            recipient_public_key: المفتاح العام للمستلم
            
        Returns:
            البيانات المشفرة في حاوية SHEP
        """
        # 1. توليد مفتاح AES-256 عشوائي
        aes_key = AESGCM.generate_key(bit_length=256)
        aesgcm = AESGCM(aes_key)
        
        # 2. توليد Nonce عشوائي (12 بايت)
        nonce = os.urandom(12)
        
        # 3. تشفير البيانات بـ AES-GCM
        ciphertext = aesgcm.encrypt(nonce, data, None)
        
        # 4. تغليف مفتاح AES بـ RSA-OAEP
        wrapped_key = recipient_public_key.encrypt(
            aes_key,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )
        
        # 5. تجميع كل شيء في حاوية SHEP
        return SHEPContainer.pack(wrapped_key, nonce, ciphertext)

    @staticmethod
    def decrypt(encrypted_data: bytes, private_key) -> bytes:
        """
        فك تشفير البيانات باستخدام المفتاح الخاص.
        
        Args:
            encrypted_data: البيانات المشفرة (حاوية SHEP)
            private_key: المفتاح الخاص
            
        Returns:
            البيانات الأصلية
        """
        # 1. تفكيك الحاوية
        unpacked = SHEPContainer.unpack(encrypted_data)
        wrapped_key = unpacked["wrapped_key"]
        nonce = unpacked["nonce"]
        ciphertext = unpacked["ciphertext"]
        
        # 2. فك تغليف مفتاح AES
        aes_key = private_key.decrypt(
            wrapped_key,
            padding.OAEP(
                mgf=padding.MGF1(algorithm=hashes.SHA256()),
                algorithm=hashes.SHA256(),
                label=None
            )
        )
        
        # 3. فك تشفير البيانات
        aesgcm = AESGCM(aes_key)
        return aesgcm.decrypt(nonce, ciphertext, None)


class DigitalSignature:
    """
    التوقيع الرقمي باستخدام RSA-PSS مع SHA-256.
    للتحقق من هوية المرسل وسلامة الرسالة.
    """
    
    @staticmethod
    def sign(message: bytes, private_key) -> bytes:
        """
        إنشاء توقيع رقمي للرسالة.
        
        Args:
            message: الرسالة الأصلية (bytes)
            private_key: المفتاح الخاص للمرسل
            
        Returns:
            التوقيع الرقمي
        """
        return private_key.sign(
            message,
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
    
    @staticmethod
    def verify(message: bytes, signature: bytes, public_key) -> bool:
        """
        التحقق من صحة التوقيع الرقمي.
        
        Args:
            message: الرسالة الأصلية
            signature: التوقيع الرقمي
            public_key: المفتاح العام للمرسل
            
        Returns:
            True إذا كان التوقيع صحيحاً
        """
        try:
            public_key.verify(
                signature,
                message,
                padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                hashes.SHA256()
            )
            return True
        except Exception:
            return False
    
    @staticmethod
    def get_fingerprint(public_key) -> str:
        """
        حساب بصمة المفتاح العام (أول 16 حرف من SHA-256).
        
        Args:
            public_key: المفتاح العام
            
        Returns:
            بصمة المفتاح (16 حرف)
        """
        public_bytes = public_key.public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo
        )
        hash_obj = hashlib.sha256(public_bytes)
        return hash_obj.hexdigest()[:16].upper()
