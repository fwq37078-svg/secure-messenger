"""
🔐 المراسل الآمن - Secure Messenger
واجهة رسومية بسيطة وأنيقة للمراسلات المشفرة
"""
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from pathlib import Path
import webbrowser
from urllib.parse import quote

from key_manager import generate_keys, load_public_key, KeyNotFoundError
from crypto_engine import DigitalSignature
from secure_message import SecureMessage


# ==================== الألوان والتصميم ====================
class Theme:
    """ألوان التطبيق - تصميم داكن أنيق"""
    BG_DARK = "#0f0f1a"
    BG_CARD = "#1a1a2e"
    BG_INPUT = "#252540"
    
    ACCENT_PRIMARY = "#8b5cf6"    # بنفسجي
    ACCENT_SECONDARY = "#06b6d4"  # سماوي
    SUCCESS = "#10b981"           # أخضر
    WARNING = "#f59e0b"           # برتقالي
    ERROR = "#ef4444"             # أحمر
    
    TEXT_PRIMARY = "#ffffff"
    TEXT_SECONDARY = "#a0a0b0"
    TEXT_MUTED = "#6b7280"
    
    FONT_TITLE = ("Segoe UI", 18, "bold")
    FONT_BODY = ("Segoe UI", 11)
    FONT_SMALL = ("Segoe UI", 9)
    FONT_MONO = ("Cascadia Code", 10)


# ==================== التطبيق الرئيسي ====================
class SecureMessengerApp:
    """تطبيق المراسل الآمن"""
    
    def __init__(self):
        self.root = tk.Tk()
        self.root.title("🔐 المراسل الآمن - Secure Messenger")
        self.root.geometry("800x700")
        self.root.configure(bg=Theme.BG_DARK)
        self.root.minsize(700, 600)
        
        # مسار المفاتيح
        self.keys_dir = Path.cwd() / "keys"
        self.keys_dir.mkdir(exist_ok=True)
        
        # المتغيرات
        self.my_private_key = tk.StringVar()
        self.recipient_public_key = tk.StringVar()
        self.sender_public_key = tk.StringVar()
        self.sign_message = tk.BooleanVar(value=True)
        self.my_fingerprint = tk.StringVar(value="---")
        
        # بناء الواجهة
        self._build_ui()
        self._refresh_keys()
    
    def _build_ui(self):
        """بناء الواجهة الرئيسية"""
        # العنوان
        header = tk.Frame(self.root, bg=Theme.BG_DARK)
        header.pack(fill="x", padx=20, pady=15)
        
        tk.Label(header, text="🔐", font=("Segoe UI Emoji", 28),
                 bg=Theme.BG_DARK, fg=Theme.ACCENT_PRIMARY).pack(side="left")
        
        title_frame = tk.Frame(header, bg=Theme.BG_DARK)
        title_frame.pack(side="left", padx=15)
        
        tk.Label(title_frame, text="المراسل الآمن", font=Theme.FONT_TITLE,
                 bg=Theme.BG_DARK, fg=Theme.TEXT_PRIMARY).pack(anchor="w")
        tk.Label(title_frame, text="رسائل مشفرة مع التوقيع الرقمي", 
                 font=Theme.FONT_SMALL, bg=Theme.BG_DARK, 
                 fg=Theme.TEXT_SECONDARY).pack(anchor="w")
        
        # شريط الحالة (أسفل الشاشة - نضعه أولاً)
        self.status_label = tk.Label(self.root, text="جاهز", 
                                     font=Theme.FONT_SMALL,
                                     bg=Theme.BG_DARK, fg=Theme.TEXT_MUTED)
        self.status_label.pack(side="bottom", pady=10)
        
        # المحتوى الرئيسي (قابل للتمرير)
        container = tk.Frame(self.root, bg=Theme.BG_DARK)
        container.pack(fill="both", expand=True, padx=20)
        
        self.main_canvas = tk.Canvas(container, bg=Theme.BG_DARK, highlightthickness=0)
        scrollbar = ttk.Scrollbar(container, orient="vertical", command=self.main_canvas.yview)
        
        self.main_frame = tk.Frame(self.main_canvas, bg=Theme.BG_DARK)
        
        # ربط حجم الإطار بحجم Canvas
        self.main_canvas.bind('<Configure>', self._on_canvas_configure)
        self.main_frame.bind("<Configure>", 
            lambda e: self.main_canvas.configure(scrollregion=self.main_canvas.bbox("all")))
        
        self.canvas_window = self.main_canvas.create_window((0, 0), window=self.main_frame, anchor="nw")
        self.main_canvas.configure(yscrollcommand=scrollbar.set)
        
        # تمرير بالماوس
        self.main_canvas.bind_all("<MouseWheel>", 
            lambda e: self.main_canvas.yview_scroll(int(-1*(e.delta/120)), "units"))
        
        scrollbar.pack(side="right", fill="y")
        self.main_canvas.pack(side="left", fill="both", expand=True)
        
        # البطاقات
        self._build_identity_card()
        self._build_send_card()
        self._build_receive_card()
    
    def _on_canvas_configure(self, event):
        """تحديث عرض الإطار ليتناسب مع Canvas"""
        self.main_canvas.itemconfig(self.canvas_window, width=event.width)
    
    def _create_card(self, parent, title: str, icon: str, color: str) -> tk.Frame:
        """إنشاء بطاقة"""
        card = tk.Frame(parent, bg=Theme.BG_CARD, padx=20, pady=15)
        card.pack(fill="x", pady=8)
        
        # العنوان
        header = tk.Frame(card, bg=Theme.BG_CARD)
        header.pack(fill="x", pady=(0, 12))
        
        tk.Label(header, text=icon, font=("Segoe UI Emoji", 18),
                 bg=Theme.BG_CARD, fg=color).pack(side="left")
        tk.Label(header, text=title, font=("Segoe UI", 13, "bold"),
                 bg=Theme.BG_CARD, fg=color).pack(side="left", padx=10)
        
        return card
    
    def _build_identity_card(self):
        """بطاقة الهوية"""
        card = self._create_card(self.main_frame, "هويتي", "👤", Theme.ACCENT_PRIMARY)
        
        # اختيار المفتاح الخاص
        row1 = tk.Frame(card, bg=Theme.BG_CARD)
        row1.pack(fill="x", pady=5)
        
        tk.Label(row1, text="مفتاحي الخاص:", font=Theme.FONT_BODY,
                 bg=Theme.BG_CARD, fg=Theme.TEXT_SECONDARY).pack(side="left")
        
        self.private_key_combo = ttk.Combobox(row1, textvariable=self.my_private_key,
                                               state="readonly", width=30)
        self.private_key_combo.pack(side="left", padx=10)
        self.private_key_combo.bind("<<ComboboxSelected>>", self._on_key_changed)
        
        # البصمة
        row2 = tk.Frame(card, bg=Theme.BG_CARD)
        row2.pack(fill="x", pady=5)
        
        tk.Label(row2, text="🔏 بصمتي:", font=Theme.FONT_SMALL,
                 bg=Theme.BG_CARD, fg=Theme.TEXT_MUTED).pack(side="left")
        tk.Label(row2, textvariable=self.my_fingerprint, font=Theme.FONT_MONO,
                 bg=Theme.BG_CARD, fg=Theme.ACCENT_SECONDARY).pack(side="left", padx=10)
        
        tk.Button(row2, text="📋 نسخ", command=self._copy_fingerprint,
                  bg=Theme.BG_INPUT, fg=Theme.TEXT_PRIMARY, relief="flat",
                  padx=8, cursor="hand2").pack(side="left")
        
        # أزرار
        row3 = tk.Frame(card, bg=Theme.BG_CARD)
        row3.pack(fill="x", pady=(10, 0))
        
        tk.Button(row3, text="➕ مفتاح جديد", command=self._generate_new_key,
                  bg=Theme.BG_INPUT, fg=Theme.TEXT_PRIMARY, relief="flat",
                  padx=15, pady=8, cursor="hand2").pack(side="left")
        
        tk.Button(row3, text="📤 مشاركة مفتاحي العام", command=self._share_public_key,
                  bg=Theme.ACCENT_PRIMARY, fg="white", relief="flat",
                  padx=15, pady=8, cursor="hand2").pack(side="left", padx=10)
    
    def _build_send_card(self):
        """بطاقة الإرسال"""
        card = self._create_card(self.main_frame, "إرسال رسالة مشفرة", "📤", 
                                 Theme.ACCENT_SECONDARY)
        
        # اختيار المستلم
        row1 = tk.Frame(card, bg=Theme.BG_CARD)
        row1.pack(fill="x", pady=5)
        
        tk.Label(row1, text="إلى (المفتاح العام للمستلم):", font=Theme.FONT_BODY,
                 bg=Theme.BG_CARD, fg=Theme.TEXT_SECONDARY).pack(side="left")
        
        self.recipient_combo = ttk.Combobox(row1, textvariable=self.recipient_public_key,
                                            state="readonly", width=30)
        self.recipient_combo.pack(side="left", padx=10)
        
        tk.Button(row1, text="📥 استيراد", command=self._import_key,
                  bg=Theme.BG_INPUT, fg=Theme.TEXT_PRIMARY, relief="flat",
                  padx=8, cursor="hand2").pack(side="left")
        
        # نص الرسالة
        tk.Label(card, text="نص الرسالة:", font=Theme.FONT_SMALL,
                 bg=Theme.BG_CARD, fg=Theme.TEXT_MUTED).pack(anchor="w", pady=(10, 2))
        
        self.message_input = tk.Text(card, height=3, bg=Theme.BG_INPUT,
                                     fg=Theme.TEXT_PRIMARY, relief="flat",
                                     font=Theme.FONT_BODY, insertbackground="white")
        self.message_input.pack(fill="x", pady=2)
        
        # خيار التوقيع
        sign_frame = tk.Frame(card, bg=Theme.BG_CARD)
        sign_frame.pack(fill="x", pady=8)
        
        tk.Checkbutton(sign_frame, text="✍️ إضافة توقيعي الرقمي",
                       variable=self.sign_message, bg=Theme.BG_CARD,
                       fg=Theme.TEXT_PRIMARY, selectcolor=Theme.BG_INPUT,
                       activebackground=Theme.BG_CARD, cursor="hand2").pack(side="left")
        
        # زر التشفير
        tk.Button(card, text="🔒 تشفير وإرسال", command=self._encrypt_message,
                  bg=Theme.ACCENT_PRIMARY, fg="white", relief="flat",
                  font=Theme.FONT_BODY, padx=20, pady=10, cursor="hand2").pack(anchor="e", pady=5)
        
        # الناتج
        tk.Label(card, text="الرسالة المشفرة:", font=Theme.FONT_SMALL,
                 bg=Theme.BG_CARD, fg=Theme.TEXT_MUTED).pack(anchor="w", pady=(10, 2))
        
        self.cipher_output = tk.Text(card, height=4, bg="#0f0f1a",
                                     fg=Theme.ACCENT_SECONDARY, relief="flat",
                                     font=("Cascadia Code", 9))
        self.cipher_output.pack(fill="x", pady=2)
        
        # أزرار النسخ
        btn_row = tk.Frame(card, bg=Theme.BG_CARD)
        btn_row.pack(fill="x", pady=5)
        
        tk.Button(btn_row, text="📋 نسخ", command=self._copy_cipher,
                  bg=Theme.BG_INPUT, fg=Theme.TEXT_PRIMARY, relief="flat",
                  padx=12, cursor="hand2").pack(side="left")
        
        tk.Button(btn_row, text="📱 واتساب", command=self._send_whatsapp,
                  bg="#25D366", fg="white", relief="flat",
                  padx=12, cursor="hand2").pack(side="left", padx=10)
    
    def _build_receive_card(self):
        """بطاقة الاستقبال - تصميم محسّن"""
        card = self._create_card(self.main_frame, "فك تشفير رسالة مستلمة", "🔓", 
                                 Theme.SUCCESS)
        
        # ========== 1. المفتاح الخاص للمستلم (أنا) ==========
        row1 = tk.Frame(card, bg=Theme.BG_CARD)
        row1.pack(fill="x", pady=8)
        
        tk.Label(row1, text="🔑 مفتاحي الخاص (لفك التشفير):", font=Theme.FONT_BODY,
                 bg=Theme.BG_CARD, fg=Theme.TEXT_SECONDARY).pack(anchor="w")
        
        self.decrypt_private_key = tk.StringVar()
        self.decrypt_priv_combo = ttk.Combobox(row1, textvariable=self.decrypt_private_key,
                                                state="readonly", width=35)
        self.decrypt_priv_combo.pack(anchor="w", pady=3)
        
        # ========== 2. المفتاح العام للمرسل ==========
        row2 = tk.Frame(card, bg=Theme.BG_CARD)
        row2.pack(fill="x", pady=8)
        
        tk.Label(row2, text="👤 مفتاح المرسل العام (للتحقق من هويته):", font=Theme.FONT_BODY,
                 bg=Theme.BG_CARD, fg=Theme.TEXT_SECONDARY).pack(anchor="w")
        
        sender_frame = tk.Frame(row2, bg=Theme.BG_CARD)
        sender_frame.pack(anchor="w", pady=3)
        
        self.sender_combo = ttk.Combobox(sender_frame, textvariable=self.sender_public_key,
                                         state="readonly", width=30)
        self.sender_combo.pack(side="left")
        
        tk.Label(sender_frame, text="(اختياري - للتحقق من الهوية)", font=Theme.FONT_SMALL,
                 bg=Theme.BG_CARD, fg=Theme.TEXT_MUTED).pack(side="left", padx=10)
        
        # ========== 3. الرسالة المشفرة ==========
        row3 = tk.Frame(card, bg=Theme.BG_CARD)
        row3.pack(fill="x", pady=8)
        
        tk.Label(row3, text="📩 الرسالة المشفرة:", font=Theme.FONT_BODY,
                 bg=Theme.BG_CARD, fg=Theme.TEXT_SECONDARY).pack(anchor="w")
        
        self.cipher_input = tk.Text(row3, height=4, bg=Theme.BG_INPUT,
                                    fg=Theme.TEXT_MUTED, relief="flat",
                                    font=("Cascadia Code", 9))
        self.cipher_input.pack(fill="x", pady=3)
        
        # زر اللصق
        tk.Button(row3, text="📋 لصق من الحافظة", command=self._paste_cipher,
                  bg=Theme.BG_INPUT, fg=Theme.TEXT_PRIMARY, relief="flat",
                  padx=12, pady=5, cursor="hand2").pack(anchor="w", pady=5)
        
        # ========== 4. زر فك التشفير ==========
        tk.Button(card, text="🔓 فك التشفير والتحقق", command=self._decrypt_message,
                  bg=Theme.SUCCESS, fg="white", relief="flat",
                  font=("Segoe UI", 12, "bold"), padx=25, pady=12, 
                  cursor="hand2").pack(pady=15)
        
        # ========== 5. النتائج ==========
        results_frame = tk.Frame(card, bg="#1e1e35", padx=15, pady=15)
        results_frame.pack(fill="x", pady=5)
        
        tk.Label(results_frame, text="📊 النتائج:", font=("Segoe UI", 12, "bold"),
                 bg="#1e1e35", fg=Theme.ACCENT_PRIMARY).pack(anchor="w", pady=(0, 10))
        
        # اسم المرسل
        sender_row = tk.Frame(results_frame, bg="#1e1e35")
        sender_row.pack(fill="x", pady=3)
        
        tk.Label(sender_row, text="المرسل:", font=Theme.FONT_BODY,
                 bg="#1e1e35", fg=Theme.TEXT_MUTED).pack(side="left")
        
        self.sender_name_var = tk.StringVar(value="---")
        tk.Label(sender_row, textvariable=self.sender_name_var, font=("Segoe UI", 11, "bold"),
                 bg="#1e1e35", fg=Theme.ACCENT_SECONDARY).pack(side="left", padx=10)
        
        # حالة التحقق
        self.verify_status = tk.StringVar(value="---")
        self.verify_label = tk.Label(results_frame, textvariable=self.verify_status,
                                     font=Theme.FONT_BODY, bg="#1e1e35",
                                     fg=Theme.TEXT_MUTED)
        self.verify_label.pack(anchor="w", pady=5)
        
        # الرسالة الأصلية
        tk.Label(results_frame, text="الرسالة الأصلية:", font=Theme.FONT_BODY,
                 bg="#1e1e35", fg=Theme.TEXT_MUTED).pack(anchor="w", pady=(10, 3))
        
        self.plaintext_output = tk.Text(results_frame, height=3, bg=Theme.BG_INPUT,
                                        fg=Theme.TEXT_PRIMARY, relief="flat",
                                        font=Theme.FONT_BODY)
        self.plaintext_output.pack(fill="x", pady=3)
    
    # ==================== الوظائف ====================
    
    def _show_status(self, message: str, type: str = "info"):
        """عرض رسالة في شريط الحالة"""
        colors = {
            "success": Theme.SUCCESS,
            "error": Theme.ERROR,
            "warning": Theme.WARNING,
            "info": Theme.TEXT_MUTED
        }
        self.status_label.config(text=message, fg=colors.get(type, Theme.TEXT_MUTED))
    
    def _refresh_keys(self):
        """تحديث قوائم المفاتيح"""
        # المفاتيح الخاصة
        private_keys = list(self.keys_dir.glob("*_private.pem"))
        private_names = [k.name for k in private_keys]
        self.private_key_combo['values'] = private_names
        self.decrypt_priv_combo['values'] = private_names  # قائمة فك التشفير
        if private_names:
            self.private_key_combo.current(0)
            self.decrypt_priv_combo.current(0)  # تحديد أول مفتاح
            self._update_fingerprint()
        
        # المفاتيح العامة
        public_keys = list(self.keys_dir.glob("*_public.pem"))
        public_names = [k.name for k in public_keys]
        self.recipient_combo['values'] = public_names
        self.sender_combo['values'] = public_names
    
    def _on_key_changed(self, event=None):
        """عند تغيير المفتاح المختار"""
        self._update_fingerprint()
    
    def _update_fingerprint(self):
        """تحديث البصمة"""
        priv_name = self.my_private_key.get()
        if not priv_name:
            self.my_fingerprint.set("---")
            return
        
        # استنتاج اسم المفتاح العام
        pub_name = priv_name.replace("_private.pem", "_public.pem")
        pub_path = self.keys_dir / pub_name
        
        if pub_path.exists():
            try:
                pub_key = load_public_key(str(pub_path))
                fp = DigitalSignature.get_fingerprint(pub_key)
                self.my_fingerprint.set(fp)
            except:
                self.my_fingerprint.set("خطأ")
        else:
            self.my_fingerprint.set("غير موجود")
    
    def _copy_fingerprint(self):
        """نسخ البصمة"""
        fp = self.my_fingerprint.get()
        if fp and fp not in ["---", "خطأ", "غير موجود"]:
            self.root.clipboard_clear()
            self.root.clipboard_append(fp)
            self._show_status("تم نسخ البصمة! 📋", "success")
    
    def _generate_new_key(self):
        """إنشاء مفتاح جديد"""
        name = tk.simpledialog.askstring("اسم المفتاح", "أدخل اسماً للمفتاح الجديد:",
                                         parent=self.root)
        if name:
            try:
                generate_keys(str(self.keys_dir), name)
                self._refresh_keys()
                self._show_status(f"تم إنشاء مفتاح '{name}' بنجاح! ✅", "success")
            except Exception as e:
                self._show_status(f"خطأ: {str(e)}", "error")
    
    def _share_public_key(self):
        """مشاركة المفتاح العام عبر واتساب"""
        priv_name = self.my_private_key.get()
        if not priv_name:
            self._show_status("اختر مفتاحك الخاص أولاً", "error")
            return
        
        pub_name = priv_name.replace("_private.pem", "_public.pem")
        pub_path = self.keys_dir / pub_name
        
        if pub_path.exists():
            content = pub_path.read_text()
            encoded = quote(content)
            webbrowser.open(f"https://wa.me/?text={encoded}")
            self._show_status("جاري فتح واتساب...", "success")
        else:
            self._show_status("المفتاح العام غير موجود", "error")
    
    def _import_key(self):
        """استيراد مفتاح عام"""
        file_path = filedialog.askopenfilename(
            title="اختر المفتاح العام",
            filetypes=[("PEM files", "*.pem"), ("All files", "*.*")]
        )
        if file_path:
            try:
                import shutil
                dest = self.keys_dir / Path(file_path).name
                shutil.copy(file_path, dest)
                self._refresh_keys()
                self._show_status(f"تم استيراد المفتاح! ✅", "success")
            except Exception as e:
                self._show_status(f"خطأ: {str(e)}", "error")
    
    def _encrypt_message(self):
        """تشفير الرسالة"""
        plaintext = self.message_input.get("1.0", "end-1c").strip()
        if not plaintext:
            self._show_status("أدخل نص الرسالة", "error")
            return
        
        recipient = self.recipient_public_key.get()
        if not recipient:
            self._show_status("اختر المفتاح العام للمستلم", "error")
            return
        
        try:
            recipient_path = str(self.keys_dir / recipient)
            sender_path = None
            
            if self.sign_message.get():
                priv_name = self.my_private_key.get()
                if priv_name:
                    sender_path = str(self.keys_dir / priv_name)
            
            encrypted = SecureMessage.create(
                plaintext=plaintext,
                recipient_public_key_path=recipient_path,
                sender_private_key_path=sender_path,
                sign=self.sign_message.get()
            )
            
            self.cipher_output.delete("1.0", "end")
            self.cipher_output.insert("1.0", encrypted)
            
            # مسح نص الرسالة الأصلية بعد التشفير (للأمان)
            self.message_input.delete("1.0", "end")
            
            if self.sign_message.get():
                self._show_status("✅ تم التشفير والتوقيع! (تم مسح النص الأصلي)", "success")
            else:
                self._show_status("🔒 تم التشفير! (تم مسح النص الأصلي)", "success")
                
        except Exception as e:
            self._show_status(f"خطأ: {str(e)}", "error")
    
    def _decrypt_message(self):
        """فك تشفير الرسالة"""
        cipher_text = self.cipher_input.get("1.0", "end-1c").strip()
        if not cipher_text:
            self._show_status("الصق الرسالة المشفرة أولاً", "error")
            return
        
        # استخدام المفتاح الخاص من قسم فك التشفير
        priv_name = self.decrypt_private_key.get()
        if not priv_name:
            self._show_status("اختر مفتاحك الخاص لفك التشفير", "error")
            return
        
        try:
            priv_path = str(self.keys_dir / priv_name)
            sender_path = None
            sender_display_name = "غير محدد"
            
            sender_name = self.sender_public_key.get()
            if sender_name:
                sender_path = str(self.keys_dir / sender_name)
                # استخراج اسم المرسل من اسم الملف
                sender_display_name = sender_name.replace("_public.pem", "")
            
            result = SecureMessage.parse(
                encrypted_message=cipher_text,
                recipient_private_key_path=priv_path,
                sender_public_key_path=sender_path
            )
            
            # عرض النتائج
            self.plaintext_output.delete("1.0", "end")
            self.plaintext_output.insert("1.0", result['plaintext'])
            
            # عرض اسم المرسل
            if sender_name and result['verified']:
                self.sender_name_var.set(f"✅ {sender_display_name}")
            elif sender_name:
                self.sender_name_var.set(f"⚠️ {sender_display_name}")
            else:
                self.sender_name_var.set("غير محدد")
            
            self.verify_status.set(result['status'])
            
            # تلوين حالة التحقق
            if result['verified'] is True:
                self.verify_label.config(fg=Theme.SUCCESS)
            elif result['verified'] is False:
                self.verify_label.config(fg=Theme.ERROR)
            else:
                self.verify_label.config(fg=Theme.TEXT_MUTED)
            
            self._show_status("تم فك التشفير بنجاح! ✅", "success")
            
        except Exception as e:
            self._show_status(f"فشل فك التشفير: {str(e)}", "error")
            self.verify_status.set("❌ فشل فك التشفير")
            self.sender_name_var.set("---")
            self.verify_label.config(fg=Theme.ERROR)
    
    def _copy_cipher(self):
        """نسخ النص المشفر"""
        cipher = self.cipher_output.get("1.0", "end-1c").strip()
        if cipher:
            self.root.clipboard_clear()
            self.root.clipboard_append(cipher)
            self._show_status("تم النسخ! 📋", "success")
    
    def _send_whatsapp(self):
        """إرسال عبر واتساب"""
        cipher = self.cipher_output.get("1.0", "end-1c").strip()
        if cipher:
            encoded = quote(cipher)
            webbrowser.open(f"https://wa.me/?text={encoded}")
            self._show_status("جاري فتح واتساب...", "success")
    
    def _paste_cipher(self):
        """لصق من الحافظة"""
        try:
            text = self.root.clipboard_get()
            if text:
                self.cipher_input.delete("1.0", "end")
                self.cipher_input.insert("1.0", text)
                self._show_status("تم اللصق! 📋", "success")
        except:
            self._show_status("الحافظة فارغة", "warning")
    
    def run(self):
        """تشغيل التطبيق"""
        self.root.mainloop()


# ==================== التشغيل ====================
if __name__ == "__main__":
    import tkinter.simpledialog
    app = SecureMessengerApp()
    app.run()
