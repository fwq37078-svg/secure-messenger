"""
📨 محرك المراسلات الآمنة
Secure Messaging Engine - يجمع التشفير والتوقيع معاً
"""
import base64
import json
from crypto_engine import HybridEncryptor, DigitalSignature
from key_manager import load_private_key, load_public_key


class SecureMessage:
    """
    رسالة آمنة مشفرة وموقّعة.
    
    التنسيق:
    [SHEP-MSG]
    {base64 encoded JSON: version, signed, cipher, sig?}
    [/SHEP-MSG]
    """
    
    VERSION = "2.0"
    
    @staticmethod
    def create(
        plaintext: str,
        recipient_public_key_path: str,
        sender_private_key_path: str = None,
        sign: bool = True
    ) -> str:
        """
        إنشاء رسالة مشفرة (وموقّعة اختيارياً).
        
        Args:
            plaintext: النص الأصلي
            recipient_public_key_path: مسار المفتاح العام للمستلم
            sender_private_key_path: مسار المفتاح الخاص للمرسل (للتوقيع)
            sign: هل يتم توقيع الرسالة؟
            
        Returns:
            الرسالة المشفرة بتنسيق SHEP-MSG
        """
        # تحميل مفتاح المستلم العام
        recipient_pub_key = load_public_key(recipient_public_key_path)
        
        # تحويل النص إلى bytes
        data = plaintext.encode('utf-8')
        
        # تشفير الرسالة
        encrypted = HybridEncryptor.encrypt(data, recipient_pub_key)
        cipher_b64 = base64.b64encode(encrypted).decode('utf-8')
        
        # إنشاء بنية الرسالة
        message_data = {
            "v": SecureMessage.VERSION,
            "signed": False,
            "cipher": cipher_b64
        }
        
        # التوقيع إذا كان مطلوباً
        if sign and sender_private_key_path:
            sender_priv_key = load_private_key(sender_private_key_path)
            signature = DigitalSignature.sign(data, sender_priv_key)
            message_data["signed"] = True
            message_data["sig"] = base64.b64encode(signature).decode('utf-8')
        
        # تحويل إلى JSON ثم Base64
        json_str = json.dumps(message_data)
        final_b64 = base64.b64encode(json_str.encode('utf-8')).decode('utf-8')
        
        return f"[SHEP-MSG]\n{final_b64}\n[/SHEP-MSG]"
    
    @staticmethod
    def parse(
        encrypted_message: str,
        recipient_private_key_path: str,
        sender_public_key_path: str = None
    ) -> dict:
        """
        فك تشفير الرسالة والتحقق من التوقيع.
        
        Args:
            encrypted_message: الرسالة المشفرة بتنسيق SHEP-MSG
            recipient_private_key_path: مسار المفتاح الخاص للمستلم
            sender_public_key_path: مسار المفتاح العام للمرسل (للتحقق)
            
        Returns:
            dict: {
                'plaintext': النص الأصلي,
                'signed': هل كانت موقّعة,
                'verified': نتيجة التحقق (True/False/None),
                'status': حالة التحقق (نص)
            }
        """
        import re
        
        # استخراج المحتوى من التنسيق
        if "[SHEP-MSG]" in encrypted_message:
            match = re.search(r'\[SHEP-MSG\]\s*(.+?)\s*\[/SHEP-MSG\]', 
                            encrypted_message, re.DOTALL)
            if not match:
                raise ValueError("تنسيق الرسالة غير صحيح")
            
            encoded_json = match.group(1).strip()
            json_str = base64.b64decode(encoded_json).decode('utf-8')
            message_data = json.loads(json_str)
            
            is_signed = message_data.get("signed", False)
            cipher_b64 = message_data.get("cipher", "")
            sig_b64 = message_data.get("sig", "")
        else:
            # تنسيق قديم - base64 مباشر
            cipher_b64 = encrypted_message.strip()
            is_signed = False
            sig_b64 = ""
        
        # فك التشفير
        recipient_priv_key = load_private_key(recipient_private_key_path)
        encrypted_data = base64.b64decode(cipher_b64)
        plaintext_bytes = HybridEncryptor.decrypt(encrypted_data, recipient_priv_key)
        plaintext = plaintext_bytes.decode('utf-8')
        
        # التحقق من التوقيع
        verified = None
        status = "📄 رسالة غير موقّعة"
        
        if is_signed and sig_b64:
            if sender_public_key_path:
                sender_pub_key = load_public_key(sender_public_key_path)
                signature = base64.b64decode(sig_b64)
                verified = DigitalSignature.verify(plaintext_bytes, signature, sender_pub_key)
                
                if verified:
                    status = "✅ مُوثّقة - تم التحقق من هوية المرسل"
                else:
                    status = "❌ تحذير! التوقيع غير صالح - الرسالة قد تكون معدّلة!"
            else:
                status = "⚠️ موقّعة - اختر مفتاح المرسل للتحقق"
        elif is_signed:
            status = "📝 موقّعة لكن بدون مفتاح للتحقق"
        
        return {
            'plaintext': plaintext,
            'signed': is_signed,
            'verified': verified,
            'status': status
        }


# اختبار سريع
if __name__ == "__main__":
    print("✅ SecureMessage module loaded successfully!")
