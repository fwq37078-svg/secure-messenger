"""
🔐 المراسل الآمن - نسخة الموبايل
Secure Messenger - Mobile Version (Flet)
يعمل على الجوال والكمبيوتر والويب
"""
import flet as ft
from pathlib import Path
import base64
import json

from key_manager import generate_keys, load_public_key, load_private_key
from crypto_engine import HybridEncryptor, DigitalSignature
from secure_message import SecureMessage


class SecureMessengerMobile:
    """تطبيق المراسل الآمن - نسخة موبايل"""
    
    def __init__(self, page: ft.Page):
        self.page = page
        self.keys_dir = Path.cwd() / "keys"
        self.keys_dir.mkdir(exist_ok=True)
        
        # إعدادات الصفحة
        self.page.title = "🔐 المراسل الآمن"
        self.page.theme_mode = ft.ThemeMode.DARK
        self.page.padding = 20
        self.page.scroll = ft.ScrollMode.AUTO
        self.page.rtl = True  # دعم العربية
        
        # الألوان
        self.primary_color = "#8b5cf6"
        self.success_color = "#10b981"
        self.error_color = "#ef4444"
        
        # بناء الواجهة
        self._build_ui()
        self._refresh_keys()
    
    def _build_ui(self):
        """بناء الواجهة"""
        
        # العنوان
        header = ft.Container(
            content=ft.Row([
                ft.Text("🔐", size=40),
                ft.Column([
                    ft.Text("المراسل الآمن", size=24, weight=ft.FontWeight.BOLD, color="white"),
                    ft.Text("رسائل مشفرة مع التوقيع الرقمي", size=14, color="#a0a0b0"),
                ], spacing=0),
            ]),
            padding=10,
        )
        
        # ========== قسم الهوية ==========
        self.private_key_dropdown = ft.Dropdown(
            label="🔑 مفتاحي الخاص",
            width=300,
            on_change=self._on_key_changed,
        )
        
        self.fingerprint_text = ft.Text("---", color="#06b6d4", size=12)
        
        identity_card = self._create_card(
            "👤 هويتي",
            ft.Column([
                self.private_key_dropdown,
                ft.Row([
                    ft.Text("البصمة:", size=12, color="#6b7280"),
                    self.fingerprint_text,
                ]),
                ft.Row([
                    ft.ElevatedButton(
                        "➕ مفتاح جديد",
                        on_click=self._generate_key,
                        bgcolor="#252540",
                        color="white",
                    ),
                    ft.ElevatedButton(
                        "📤 مشاركة مفتاحي",
                        on_click=self._share_public_key,
                        bgcolor=self.primary_color,
                        color="white",
                    ),
                ], wrap=True),
            ]),
            self.primary_color
        )
        
        # ========== قسم الإرسال ==========
        self.recipient_dropdown = ft.Dropdown(
            label="📧 إلى (المفتاح العام للمستلم)",
            width=300,
        )
        
        self.message_input = ft.TextField(
            label="✏️ نص الرسالة",
            multiline=True,
            min_lines=3,
            max_lines=5,
        )
        
        self.sign_checkbox = ft.Checkbox(
            label="✍️ إضافة توقيعي الرقمي",
            value=True,
        )
        
        self.cipher_output = ft.TextField(
            label="📦 الرسالة المشفرة",
            multiline=True,
            min_lines=3,
            max_lines=5,
            read_only=True,
            bgcolor="#0f0f1a",
        )
        
        send_card = self._create_card(
            "📤 إرسال رسالة مشفرة",
            ft.Column([
                self.recipient_dropdown,
                self.message_input,
                self.sign_checkbox,
                ft.ElevatedButton(
                    "🔒 تشفير وإرسال",
                    on_click=self._encrypt_message,
                    bgcolor=self.primary_color,
                    color="white",
                    width=200,
                ),
                self.cipher_output,
                ft.Row([
                    ft.ElevatedButton("📋 نسخ", on_click=self._copy_cipher, bgcolor="#252540", color="white"),
                    ft.ElevatedButton("📱 واتساب", on_click=self._send_whatsapp, bgcolor="#25D366", color="white"),
                ], wrap=True),
            ]),
            "#06b6d4"
        )
        
        # ========== قسم الاستقبال ==========
        self.decrypt_key_dropdown = ft.Dropdown(
            label="🔑 مفتاحي الخاص (لفك التشفير)",
            width=300,
        )
        
        self.sender_dropdown = ft.Dropdown(
            label="👤 مفتاح المرسل العام (للتحقق)",
            width=300,
        )
        
        self.cipher_input = ft.TextField(
            label="📩 الرسالة المشفرة",
            multiline=True,
            min_lines=3,
            max_lines=5,
        )
        
        self.sender_name_text = ft.Text("---", size=16, weight=ft.FontWeight.BOLD, color="#06b6d4")
        self.verify_status_text = ft.Text("---", size=14)
        
        self.plaintext_output = ft.TextField(
            label="📨 الرسالة الأصلية",
            multiline=True,
            min_lines=2,
            max_lines=4,
            read_only=True,
            bgcolor="#1e1e35",
        )
        
        receive_card = self._create_card(
            "🔓 فك تشفير رسالة مستلمة",
            ft.Column([
                self.decrypt_key_dropdown,
                self.sender_dropdown,
                ft.Text("(اختياري - للتحقق من هوية المرسل)", size=12, color="#6b7280"),
                self.cipher_input,
                ft.ElevatedButton("📋 لصق من الحافظة", on_click=self._paste_cipher, bgcolor="#252540", color="white"),
                ft.ElevatedButton(
                    "🔓 فك التشفير والتحقق",
                    on_click=self._decrypt_message,
                    bgcolor=self.success_color,
                    color="white",
                    width=250,
                ),
                ft.Container(
                    content=ft.Column([
                        ft.Text("📊 النتائج:", size=16, weight=ft.FontWeight.BOLD, color=self.primary_color),
                        ft.Row([ft.Text("المرسل:", color="#6b7280"), self.sender_name_text]),
                        self.verify_status_text,
                        self.plaintext_output,
                    ]),
                    bgcolor="#1e1e35",
                    padding=15,
                    border_radius=10,
                ),
            ]),
            self.success_color
        )
        
        # شريط الحالة
        self.status_text = ft.Text("جاهز ✅", size=12, color="#6b7280")
        
        # إضافة كل العناصر للصفحة
        self.page.add(
            header,
            identity_card,
            send_card,
            receive_card,
            ft.Container(content=self.status_text, alignment=ft.alignment.center, padding=10),
        )
    
    def _create_card(self, title: str, content: ft.Control, color: str) -> ft.Container:
        """إنشاء بطاقة"""
        return ft.Container(
            content=ft.Column([
                ft.Row([
                    ft.Text(title, size=16, weight=ft.FontWeight.BOLD, color=color),
                ]),
                ft.Divider(height=1, color="#333"),
                content,
            ]),
            bgcolor="#1a1a2e",
            padding=20,
            border_radius=15,
            margin=ft.margin.only(bottom=15),
        )
    
    def _refresh_keys(self):
        """تحديث قوائم المفاتيح"""
        private_keys = list(self.keys_dir.glob("*_private.pem"))
        private_options = [ft.dropdown.Option(k.name) for k in private_keys]
        
        public_keys = list(self.keys_dir.glob("*_public.pem"))
        public_options = [ft.dropdown.Option(k.name) for k in public_keys]
        
        self.private_key_dropdown.options = private_options
        self.decrypt_key_dropdown.options = private_options
        self.recipient_dropdown.options = public_options
        self.sender_dropdown.options = public_options
        
        if private_options:
            self.private_key_dropdown.value = private_options[0].key
            self.decrypt_key_dropdown.value = private_options[0].key
            self._update_fingerprint()
        
        self.page.update()
    
    def _on_key_changed(self, e):
        """عند تغيير المفتاح"""
        self._update_fingerprint()
    
    def _update_fingerprint(self):
        """تحديث البصمة"""
        priv_name = self.private_key_dropdown.value
        if not priv_name:
            self.fingerprint_text.value = "---"
            self.page.update()
            return
        
        pub_name = priv_name.replace("_private.pem", "_public.pem")
        pub_path = self.keys_dir / pub_name
        
        if pub_path.exists():
            try:
                pub_key = load_public_key(str(pub_path))
                fp = DigitalSignature.get_fingerprint(pub_key)
                self.fingerprint_text.value = fp
            except:
                self.fingerprint_text.value = "خطأ"
        else:
            self.fingerprint_text.value = "غير موجود"
        
        self.page.update()
    
    def _show_status(self, message: str, type: str = "info"):
        """عرض رسالة الحالة"""
        colors = {"success": self.success_color, "error": self.error_color, "info": "#6b7280"}
        self.status_text.value = message
        self.status_text.color = colors.get(type, "#6b7280")
        self.page.update()
    
    def _generate_key(self, e):
        """إنشاء مفتاح جديد"""
        def close_dialog(e):
            dialog.open = False
            self.page.update()
        
        def create_key(e):
            name = name_field.value.strip()
            if name:
                try:
                    generate_keys(str(self.keys_dir), name)
                    self._refresh_keys()
                    self._show_status(f"تم إنشاء مفتاح '{name}' ✅", "success")
                except Exception as ex:
                    self._show_status(f"خطأ: {str(ex)}", "error")
            dialog.open = False
            self.page.update()
        
        name_field = ft.TextField(label="اسم المفتاح", autofocus=True)
        dialog = ft.AlertDialog(
            title=ft.Text("إنشاء مفتاح جديد"),
            content=name_field,
            actions=[
                ft.TextButton("إلغاء", on_click=close_dialog),
                ft.TextButton("إنشاء", on_click=create_key),
            ],
        )
        self.page.overlay.append(dialog)
        dialog.open = True
        self.page.update()
    
    def _share_public_key(self, e):
        """مشاركة المفتاح العام"""
        priv_name = self.private_key_dropdown.value
        if not priv_name:
            self._show_status("اختر مفتاحك أولاً", "error")
            return
        
        pub_name = priv_name.replace("_private.pem", "_public.pem")
        pub_path = self.keys_dir / pub_name
        
        if pub_path.exists():
            content = pub_path.read_text()
            self.page.set_clipboard(content)
            self._show_status("تم نسخ المفتاح العام! شاركه مع الآخرين 📋", "success")
        else:
            self._show_status("المفتاح غير موجود", "error")
    
    def _encrypt_message(self, e):
        """تشفير الرسالة"""
        plaintext = self.message_input.value.strip() if self.message_input.value else ""
        if not plaintext:
            self._show_status("أدخل نص الرسالة", "error")
            return
        
        recipient = self.recipient_dropdown.value
        if not recipient:
            self._show_status("اختر المستلم", "error")
            return
        
        try:
            recipient_path = str(self.keys_dir / recipient)
            sender_path = None
            
            if self.sign_checkbox.value:
                priv_name = self.private_key_dropdown.value
                if priv_name:
                    sender_path = str(self.keys_dir / priv_name)
            
            encrypted = SecureMessage.create(
                plaintext=plaintext,
                recipient_public_key_path=recipient_path,
                sender_private_key_path=sender_path,
                sign=self.sign_checkbox.value
            )
            
            self.cipher_output.value = encrypted
            self.message_input.value = ""  # مسح النص الأصلي
            self._show_status("✅ تم التشفير بنجاح!", "success")
            self.page.update()
            
        except Exception as ex:
            self._show_status(f"خطأ: {str(ex)}", "error")
    
    def _decrypt_message(self, e):
        """فك التشفير"""
        cipher_text = self.cipher_input.value.strip() if self.cipher_input.value else ""
        if not cipher_text:
            self._show_status("الصق الرسالة المشفرة", "error")
            return
        
        priv_name = self.decrypt_key_dropdown.value
        if not priv_name:
            self._show_status("اختر مفتاحك الخاص", "error")
            return
        
        try:
            priv_path = str(self.keys_dir / priv_name)
            sender_path = None
            sender_display = "غير محدد"
            
            sender_name = self.sender_dropdown.value
            if sender_name:
                sender_path = str(self.keys_dir / sender_name)
                sender_display = sender_name.replace("_public.pem", "")
            
            result = SecureMessage.parse(
                encrypted_message=cipher_text,
                recipient_private_key_path=priv_path,
                sender_public_key_path=sender_path
            )
            
            self.plaintext_output.value = result['plaintext']
            
            if sender_name and result['verified']:
                self.sender_name_text.value = f"✅ {sender_display}"
                self.sender_name_text.color = self.success_color
            elif sender_name:
                self.sender_name_text.value = f"⚠️ {sender_display}"
                self.sender_name_text.color = self.error_color
            else:
                self.sender_name_text.value = "غير محدد"
                self.sender_name_text.color = "#6b7280"
            
            self.verify_status_text.value = result['status']
            if result['verified']:
                self.verify_status_text.color = self.success_color
            elif result['verified'] is False:
                self.verify_status_text.color = self.error_color
            else:
                self.verify_status_text.color = "#6b7280"
            
            self._show_status("✅ تم فك التشفير!", "success")
            self.page.update()
            
        except Exception as ex:
            self._show_status(f"فشل: {str(ex)}", "error")
            self.sender_name_text.value = "---"
            self.verify_status_text.value = "❌ فشل فك التشفير"
            self.verify_status_text.color = self.error_color
            self.page.update()
    
    def _copy_cipher(self, e):
        """نسخ النص المشفر"""
        if self.cipher_output.value:
            self.page.set_clipboard(self.cipher_output.value)
            self._show_status("تم النسخ! 📋", "success")
    
    def _send_whatsapp(self, e):
        """إرسال عبر واتساب"""
        if self.cipher_output.value:
            from urllib.parse import quote
            encoded = quote(self.cipher_output.value)
            self.page.launch_url(f"https://wa.me/?text={encoded}")
            self._show_status("جاري فتح واتساب...", "success")
    
    def _paste_cipher(self, e):
        """لصق من الحافظة"""
        async def paste():
            text = await self.page.get_clipboard_async()
            if text:
                self.cipher_input.value = text
                self._show_status("تم اللصق! 📋", "success")
                self.page.update()
        
        self.page.run_task(paste)


def main(page: ft.Page):
    SecureMessengerMobile(page)


if __name__ == "__main__":
    ft.app(target=main)
