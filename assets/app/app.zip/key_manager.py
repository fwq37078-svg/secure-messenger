"""
🔐 إدارة المفاتيح - Key Manager
توليد وتحميل مفاتيح RSA-2048
"""
from pathlib import Path
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend


class KeyNotFoundError(Exception):
    """المفتاح غير موجود."""
    pass


class InvalidKeyError(Exception):
    """المفتاح غير صالح."""
    pass


def generate_keys(keys_dir: str, key_name: str = "default", passphrase: bytes = None) -> tuple:
    """
    إنشاء زوج مفاتيح RSA-2048 جديد.
    
    Args:
        keys_dir: مجلد حفظ المفاتيح
        key_name: اسم المفتاح (الافتراضي: default)
        passphrase: كلمة مرور اختيارية لتشفير المفتاح الخاص
        
    Returns:
        (مسار المفتاح الخاص, مسار المفتاح العام)
    """
    keys_path = Path(keys_dir)
    keys_path.mkdir(parents=True, exist_ok=True)
        
    # توليد المفتاح الخاص
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
        backend=default_backend()
    )
    
    # خوارزمية التشفير
    if passphrase:
        encryption_algo = serialization.BestAvailableEncryption(passphrase)
    else:
        encryption_algo = serialization.NoEncryption()
    
    # حفظ المفتاح الخاص
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=encryption_algo
    )
    
    private_path = keys_path / f"{key_name}_private.pem"
    private_path.write_bytes(private_pem)
        
    # استخراج وحفظ المفتاح العام
    public_key = private_key.public_key()
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    )
    
    public_path = keys_path / f"{key_name}_public.pem"
    public_path.write_bytes(public_pem)
    
    return (str(private_path.resolve()), str(public_path.resolve()))


def load_private_key(path: str, password: bytes = None):
    """تحميل المفتاح الخاص من ملف PEM."""
    key_path = Path(path)
    if not key_path.exists():
        raise KeyNotFoundError(f"المفتاح الخاص غير موجود: {path}")
        
    try:
        return serialization.load_pem_private_key(
            key_path.read_bytes(),
            password=password,
            backend=default_backend()
        )
    except TypeError:
        raise InvalidKeyError("المفتاح مشفر. أدخل كلمة المرور.")
    except Exception as e:
        raise InvalidKeyError(f"فشل تحميل المفتاح: {str(e)}")


def load_public_key(path: str):
    """تحميل المفتاح العام من ملف PEM."""
    key_path = Path(path)
    if not key_path.exists():
        raise KeyNotFoundError(f"المفتاح العام غير موجود: {path}")
        
    try:
        return serialization.load_pem_public_key(
            key_path.read_bytes(),
            backend=default_backend()
        )
    except Exception as e:
        raise InvalidKeyError(f"فشل تحميل المفتاح: {str(e)}")
