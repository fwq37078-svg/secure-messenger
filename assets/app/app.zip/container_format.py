"""
SHEP (Secure Hybrid Encrypted Payload) Container Format.
تنسيق حاوية البيانات المشفرة.
"""
import struct


class SHEPContainer:
    """
    حاوية البيانات المشفرة بتنسيق SHEP.
    
    البنية:
    - Magic: SHEP (4 bytes)
    - Version: 1 (1 byte)
    - Algorithm IDs: AES-GCM (1 byte) + RSA-OAEP-SHA256 (1 byte)
    - Lengths: wrapped_key_len (4), nonce_len (4), ciphertext_len (4) [Big-Endian]
    - Payloads: wrapped_key, nonce, ciphertext
    """
    
    MAGIC = b'SHEP'
    VERSION = 1
    ALG_AES_GCM = 1
    ALG_RSA_OAEP_SHA256 = 1
    
    HEADER_FORMAT = ">4sBBBIII"  # 4 + 1 + 1 + 1 + 4 + 4 + 4 = 19 bytes
    HEADER_SIZE = struct.calcsize(HEADER_FORMAT)
    
    # حدود الأمان
    MAX_WRAPPED_KEY_SIZE = 4096       # 4KB للمفتاح المغلف
    MAX_NONCE_SIZE = 128              # Nonce قياسي 12 بايت
    MAX_CIPHERTEXT_SIZE = 100 * 1024 * 1024  # 100MB حد أقصى للرسائل

    @staticmethod
    def pack(wrapped_key: bytes, nonce: bytes, ciphertext: bytes) -> bytes:
        """تغليف البيانات المشفرة في حاوية SHEP."""
        
        if len(wrapped_key) > SHEPContainer.MAX_WRAPPED_KEY_SIZE:
            raise ValueError("المفتاح المغلف كبير جداً")
        if len(nonce) > SHEPContainer.MAX_NONCE_SIZE:
            raise ValueError("الـ Nonce كبير جداً")
        if len(ciphertext) > SHEPContainer.MAX_CIPHERTEXT_SIZE:
            raise ValueError("النص المشفر كبير جداً")

        header = struct.pack(
            SHEPContainer.HEADER_FORMAT,
            SHEPContainer.MAGIC,
            SHEPContainer.VERSION,
            SHEPContainer.ALG_AES_GCM,
            SHEPContainer.ALG_RSA_OAEP_SHA256,
            len(wrapped_key),
            len(nonce),
            len(ciphertext)
        )
        return header + wrapped_key + nonce + ciphertext

    @staticmethod
    def unpack(data: bytes) -> dict:
        """فك تغليف حاوية SHEP واستخراج البيانات."""
        
        if len(data) < SHEPContainer.HEADER_SIZE:
            raise ValueError("البيانات قصيرة جداً")
            
        magic, version, aes_id, rsa_id, k_len, n_len, c_len = struct.unpack(
            SHEPContainer.HEADER_FORMAT, 
            data[:SHEPContainer.HEADER_SIZE]
        )
        
        # التحقق من الصحة
        if magic != SHEPContainer.MAGIC:
            raise ValueError("ليس ملف SHEP صالح")
        if version != SHEPContainer.VERSION:
            raise ValueError(f"إصدار غير مدعوم: {version}")
            
        total_size = SHEPContainer.HEADER_SIZE + k_len + n_len + c_len
        if len(data) < total_size:
            raise ValueError("البيانات مقطوعة")
            
        offset = SHEPContainer.HEADER_SIZE
        wrapped_key = data[offset:offset + k_len]
        offset += k_len
        nonce = data[offset:offset + n_len]
        offset += n_len
        ciphertext = data[offset:offset + c_len]
        
        return {
            "wrapped_key": wrapped_key,
            "nonce": nonce,
            "ciphertext": ciphertext,
            "version": version
        }
